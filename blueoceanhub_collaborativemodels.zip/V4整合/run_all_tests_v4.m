function report=run_all_tests_v4()
%RUN_ALL_TESTS_V4 Acceptance tests for the Chapter 4.1--4.9 V4 integration.
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'library','4.2变量与接口'), ...
    fullfile(here,'integration','common'), ...
    fullfile(here,'modules','4.3_source','integration'), ...
    fullfile(here,'modules','4.4_bus','integration'), ...
    fullfile(here,'modules','4.5_storage_hydrogen','integration'), ...
    fullfile(here,'modules','4.8_objectives','model'), ...
    fullfile(here,'modules','4.9_dispatch','model'));
tests={@test_snapshot_hashes,@test_frozen_schema,@test_4_3_existing, ...
    @test_joint_run,@test_4_9_dispatch,@test_4_8_evaluation,@test_no_duplicate_ledger};
names=["V4快照哈希","4.1-4.2冻结Schema","4.3既有模型", ...
    "4.3-4.9联合链路","4.9调度约束","4.8三目标评价","损耗与总账去重"];
passed=false(numel(tests),1); message=strings(numel(tests),1);
for k=1:numel(tests)
    try, tests{k}(); passed(k)=true; message(k)="PASS";
    catch ME, message(k)=string(ME.identifier)+": "+string(ME.message); end
end
report=table(names',passed,message,'VariableNames',{'Test','Passed','Message'}); disp(report);
assert(all(passed),'V4 integration acceptance failed.');
save(fullfile(here,'outputs','v4_test_report.mat'),'report');
fprintf('BLUE HUB CH4 V4: ALL TESTS PASSED\n');
end

function test_snapshot_hashes()
here=fileparts(mfilename('fullpath'));
script=fullfile(here,'build_v4_snapshot.ps1');
cmd=sprintf('powershell -ExecutionPolicy Bypass -File "%s" -VerifyOnly',script);
[status,msg]=system(cmd); assert(status==0,'V4 snapshot mismatch: %s',msg);
end

function test_frozen_schema()
here=fileparts(mfilename('fullpath')); addpath(fullfile(here,'library','4.2变量与接口'));
r=run_all_tests_4_2(); assert(all(r.Passed));
end
function test_4_3_existing()
here=fileparts(mfilename('fullpath'));
addpath(fullfile(here,'modules','4.3_source','tests'));
r=run_all_tests_4_3_v3(); assert(all(r.Passed));
end
function test_joint_run()
o=get_joint_output(); cfg=o.cfg;
for id={'4.3','4.4','4.5','4.6','4.7'}
    p=o.(['packet' strrep(id{1},'.','_')]); validate_module_packet_4_2(p,id{1},cfg,true);
end
assert(max(abs(o.packet4_4.state.pBusResidualMW))<=cfg.commonBus.balanceToleranceMW);
assert(strcmp(o.packet4_8.meta.phase,'EVALUATION'));
assert(strcmp(o.packet4_9.meta.phase,'REQUEST'));
end
function test_4_9_dispatch()
o=get_joint_output();
[p49,d]=v4_dispatch_4_9(o.cfg,o.packet4_3,o.packet4_6);
r=v4_validate_dispatch_4_9(p49,d,o.cfg,o.packet4_3,o.packet4_6,false);
assert(r.ok && strcmp(p49.audit.schedulerId,'FEASIBILITY_RULE_V4_4_9'));
assert(~contains(p49.audit.solverClass,'OPTIMALITY_CLAIM') || ...
    strcmp(p49.audit.solverClass,'DETERMINISTIC_RULE_NO_OPTIMALITY_CLAIM'));
end
function test_4_8_evaluation()
o=get_joint_output(); p=o.packet4_8;
r=v4_validate_evaluation_4_8(p,o.cfg,false); assert(r.ok);
assert(numel(p.state.objectiveVectorRaw)==3 && all(isfinite(p.state.objectiveVectorRaw)));
assert(p.product.lifecycleEmissionKgCO2e>=0 && p.product.EENSMWh>=0);
assert(strcmp(p.audit.normalizationStatus,'NOT_AVAILABLE_WITHOUT_IDEAL_AND_NADIR_CASES'));
end
function test_no_duplicate_ledger()
o=get_joint_output();
assert(o.packet4_3.loss.collectionLossAlreadyDeducted);
assert(all(o.packet4_7.service.pCableReceiveMW<=o.packet4_7.ports.exportSend.actualMW+1e-12));
assert(all(o.packet4_6.ports.dcFacility.actualMW- ...
    o.packet4_6.service.pITActualMW-o.packet4_6.service.pDCAuxActualMW<1e-8));
assert(strcmp(o.packet4_5.audit.h2DeliverySequence, ...
    '4.5_AVAILABLE_THEN_4.7_ACTUAL_THEN_4.5_COMMIT'));
end

function o=get_joint_output()
persistent cached
if isempty(cached), cached=run_v4_integration(); end
o=cached;
end
