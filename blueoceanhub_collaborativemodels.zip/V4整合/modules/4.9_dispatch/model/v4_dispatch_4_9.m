function [packet,dispatch]=v4_dispatch_4_9(cfg,p43,p46,options)
%V4_DISPATCH_4_9 Cross-module feasibility dispatch for the V4 smoke case.
% This is a deterministic feasible-rule coordinator, not a Pareto optimizer.
% Numerical preferences are [假设值，待企业调研校准].

if nargin<4 || isempty(options), options=struct; end
timeH=p43.axis.timeH(:); N=numel(timeH); dt=cfg.time.dispatchStepH;
assert(numel(p46.axis.timeH)==N && all(abs(p46.axis.timeH(:)-timeH)<1e-12), ...
    '4.3 and 4.6 time axes must match.');
marineNominal=get_option(options,'marineRequestMW',3); % [假设值，待企业调研校准]
h2Cap=get_option(options,'h2DeliveryCapKgPerH',1000); % [假设值，待企业调研校准]
assert(isscalar(marineNominal) && isfinite(marineNominal) && marineNominal>=0);
assert(isscalar(h2Cap) && isfinite(h2Cap) && h2Cap>=0);

marineReq=marineNominal*ones(N,1);
elyReq=zeros(N,1); chReq=zeros(N,1); disReq=zeros(N,1);
exportReq=zeros(N,1); spill=zeros(N,1); unserved=zeros(N,1);
energyPlan=zeros(N,1);
ePrev=cfg.bess.socInitial*cfg.bess.energyMWh;
base=p43.ports.source.actualMW-p43.loss.pSourceAuxLoadMW ...
    -cfg.commonBus.commonAuxMW-cfg.commonBus.postPOILossMW ...
    -p46.ports.dcFacility.actualMW-marineReq;

for t=1:N
    surplus=base(t);
    if surplus>=cfg.hydrogen.electrolyzerMinMW
        elyReq(t)=min(cfg.hydrogen.electrolyzerMinMW,surplus);
        surplus=surplus-elyReq(t);
    end
    if surplus>=0
        room=max(0,cfg.bess.socMax*cfg.bess.energyMWh-ePrev);
        chReq(t)=min([surplus,cfg.bess.chargeMaxMW,room/(cfg.bess.etaCharge*dt)]);
        ePrev=ePrev+cfg.bess.etaCharge*chReq(t)*dt;
        surplus=surplus-chReq(t);
        exportReq(t)=min([surplus,cfg.output.cableSendCapacityMW,cfg.output.gridAcceptMaxMW]);
        spill(t)=max(0,surplus-exportReq(t));
    else
        available=max(0,ePrev-cfg.bess.socMin*cfg.bess.energyMWh);
        disReq(t)=min([-surplus,cfg.bess.dischargeMaxMW,available*cfg.bess.etaDischarge/dt]);
        ePrev=ePrev-disReq(t)*dt/cfg.bess.etaDischarge;
        remaining=max(0,-surplus-disReq(t));
        if remaining>0
            reduction=min(marineReq(t),remaining);
            marineReq(t)=marineReq(t)-reduction;
            remaining=remaining-reduction;
        end
        unserved(t)=remaining;
    end
    energyPlan(t)=ePrev;
end

dispatch=struct;
dispatch.req45=struct('bessChargeMW',chReq,'bessDischargeMW',disReq, ...
    'electrolyzerMW',elyReq);
dispatch.exportRequestedMW=exportReq;
dispatch.marineRequestedMW=marineReq;
dispatch.h2DeliveryCapKgPerH=h2Cap*ones(N,1);
dispatch.spillPlannedMW=spill;
dispatch.unservedPlannedMW=unserved;
dispatch.bessEnergyPlanMWh=energyPlan;

packet=common_packet_4_2('4.9',timeH,cfg,'REQUEST');
packet.state.dispatchStatus=repmat("FEASIBLE",N,1);
packet.state.bessEnergyPlanMWh=energyPlan;
packet.state.pSpillPlannedMW=spill;
packet.state.pUnservedPlannedMW=unserved;
packet.service.bessChargeRequestedMW=chReq;
packet.service.bessDischargeRequestedMW=disReq;
packet.service.electrolyzerRequestedMW=elyReq;
packet.service.exportRequestedMW=exportReq;
packet.service.marineRequestedMW=marineReq;
packet.product.h2DeliveryCapKgPerH=dispatch.h2DeliveryCapKgPerH;
packet.quality.dataSourceType="RULE_BASED_INTERFACE_SMOKE";
packet.quality.calibrationVersion="UNCALIBRATED";
packet.audit.schedulerId='FEASIBILITY_RULE_V4_4_9';
packet.audit.solverClass='DETERMINISTIC_RULE_NO_OPTIMALITY_CLAIM';
packet.audit.preferenceNotice='[假设值，待企业调研校准]';
packet.audit.dynamicValidationStatus='NOT_PERFORMED';
v4_validate_dispatch_4_9(packet,dispatch,cfg,p43,p46,true);
end

function value=get_option(options,name,defaultValue)
if isfield(options,name), value=options.(name); else, value=defaultValue; end
end
